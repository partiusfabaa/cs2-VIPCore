﻿using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Menu;
using CounterStrikeSharp.API.Modules.Utils;
using Modularity;
using VipCoreApi;
using static VipCoreApi.IVipCoreApi;

namespace VIP_Skins;

public class VipSkins : BasePlugin, IModulePlugin
{
    public override string ModuleAuthor => "thesamefabius";
    public override string ModuleName => "[VIP] Skins";
    public override string ModuleVersion => "v1.0.0";

    private Skins _skins;
    private IVipCoreApi _api;

    public void LoadModule(IApiProvider provider)
    {
        _api = provider.Get<IVipCoreApi>();
        _skins = new Skins(this, _api);
        _api.RegisterFeature(_skins, FeatureType.Selectable, _skins.SelectItem);
    }

    public override void Unload(bool hotReload)
    {
        _api.UnRegisterFeature(_skins);
    }
}

public class Skins : VipFeatureBase
{
    private readonly VipSkins _vipSkins;
    public override string Feature => "skins";

    private readonly Config _config;
    public readonly Dictionary<ulong, string> PlayerModel = new();

    public Skins(VipSkins vipSkins, IVipCoreApi api) : base(api)
    {
        _vipSkins = vipSkins;
        _config = LoadConfig<Config>("vip_skins");

        vipSkins.RegisterListener<Listeners.OnMapStart>(name =>
        {
            foreach (var keyValuePair in _config.Skins)
            {
                Server.PrecacheModel(keyValuePair.Value.Path);
            }
        });

        vipSkins.RegisterEventHandler<EventPlayerSpawn>(EventPlayerSpawn);
    }

    public override void OnPlayerLoaded(CCSPlayerController player, string group)
    {
        var cookie = PlayerHasFeature(player)
            ? GetPlayerCookie<string>(player.SteamID, "vip_skins_last")
            : string.Empty;

        if (PlayerModel.TryAdd(player.SteamID, cookie)) return;
        
        PlayerModel[player.SteamID] = cookie;
    }

    // public override void OnPlayerSpawn(CCSPlayerController player)
    // {
    //     if (!PlayerHasFeature(player)) return;
    //     if (string.IsNullOrEmpty(PlayerModel[player.Slot])) return;
    //
    //     var playerPawn = player.PlayerPawn.Value;
    //     if (playerPawn == null) return;
    //
    //     var model = PlayerModel[player.Slot];
    //     Server.NextFrame(() => playerPawn.SetModel(model));
    // }

    private HookResult EventPlayerSpawn(EventPlayerSpawn @event, GameEventInfo info)
    {
        var player = @event.Userid;
        if (player == null) return HookResult.Continue;
        
        if (!IsClientVip(player)) return HookResult.Continue;
        if (!PlayerHasFeature(player)) return HookResult.Continue;
        
        if (player.Team is not (CsTeam.Terrorist or CsTeam.CounterTerrorist)) return HookResult.Continue;
        if (!PlayerModel.TryGetValue(player.SteamID, out var value)) return HookResult.Continue;

        var playerPawn = player.PlayerPawn.Value;
        if (playerPawn == null) return HookResult.Continue;

        if (string.IsNullOrEmpty(value)) return HookResult.Continue;
        
        _vipSkins.AddTimer(_config.Delay,
            () => { Server.NextFrame(() => playerPawn.SetModel(value)); });

        return HookResult.Continue;
    }

    public void SelectItem(CCSPlayerController player, FeatureState state)
    {
        var menu = new ChatMenu("Skins");
        
        if (!PlayerModel.ContainsKey(player.SteamID)) return;
        
        menu.AddMenuOption(GetTranslatedText("skins.menu.Disable"),
            (controller, _) =>
            {
                PlayerModel[player.SteamID] = string.Empty;
                SetPlayerCookie(controller.SteamID, "vip_skins_last", string.Empty);
                PrintToChat(controller, GetTranslatedText("skins.Disabled"));
            },
            PlayerModel[player.SteamID] == string.Empty);

        var availableSkins = GetFeatureValue<List<string>>(player);
        foreach (var skin in _config.Skins)
        {
            if (!availableSkins.Contains(skin.Key) && !availableSkins.Contains("all"))
            {
                Console.WriteLine($"{availableSkins.Contains(skin.Key)} || {availableSkins.Contains("all")}");
                continue;
            }

            menu.AddMenuOption(skin.Value.Name, (controller, option) =>
            {
                var skinValue = skin.Value;
                
                PlayerModel[player.SteamID] = skinValue.Path;
                SetPlayerCookie(controller.SteamID, "vip_skins_last", skin.Value.Path);

                var playerPawn = controller.PlayerPawn.Value;
                if (playerPawn == null) return;

                Server.NextFrame(() => playerPawn.SetModel(skinValue.Path));
                PrintToChat(controller, GetTranslatedText("skins.SetSkin", option.Text));
            }, PlayerModel[player.SteamID] == skin.Value.Path);
        }

        ChatMenus.OpenMenu(player, menu);
    }
}

public class Config
{
    public float Delay { get; set; } = 1;

    public Dictionary<string, ConfigSkin> Skins { get; set; } = new()
    {
        ["ct_driver"] = new ConfigSkin
        {
            Name = "CT Driver",
            Path = "characters/models/ctm_diver/ctm_diver_varianta.vmdl"
        },
        ["ct_heavy"] = new ConfigSkin
        {
            Name = "CT Heavy",
            Path = "characters/models/ctm_heavy/ctm_heavy.vmdl"
        },
        ["ct_sas"] = new ConfigSkin
        {
            Name = "CT Sas",
            Path = "characters/models/ctm_sas/ctm_sas.vmdl"
        }
    };
}

public class ConfigSkin
{
    public required string Name { get; init; }
    public required string Path { get; init; }
}